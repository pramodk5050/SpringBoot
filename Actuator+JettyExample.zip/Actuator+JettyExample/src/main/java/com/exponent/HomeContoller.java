package com.exponent;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class HomeContoller {

	@RequestMapping(value = "/welcome")
	public String getMsgg() throws JsonProcessingException {

		Student s = new Student();
		s.setSid(1001);
		s.setSname("pawan");
		s.setSaddress("pune");

		ObjectMapper mapper = new ObjectMapper();

		String msg = mapper.writeValueAsString(s);

		return "Welcome to Exponent json forat is  :- " + msg;
	}
}
