package array;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class DuplicateElementCountinArray {

	public static void main(String[] args) {
		int a[] = { 1, 5, 8, 8, 4, 9, 6, 3 };
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (Integer value : a) {
			Integer cnt = map.get(value);
			if (cnt == null) {
				map.put(value, 1);
			} else {
				cnt++;
				map.put(value, cnt);
			}
		}

		Set<Entry<Integer, Integer>> kv = map.entrySet();

		for (Entry<Integer, Integer> entry : kv) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
	}
}
