package array;

public class PairsinArray {

	public static void main(String[] args) {
////		int input[] = {5,8,4,1,9,};
//		for (int i = 0; i < input.length; i++) {
//		    for (int j = 0; j < input.length; j++) {
//		        if (j != i && (input[i] + input[j]) == 5) {
//		            addPairs(input[i], 5-input[i]));
		        }
		    }
		}

	}

}
