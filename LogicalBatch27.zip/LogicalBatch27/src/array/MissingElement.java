package array;

public class MissingElement {

	public static void main(String[] args) {

		int a[] = { 1, 2, 3, 5 };
		int sum = 0;
//		boolean flag = false;
		boolean temp[] = new boolean[5];
		for (int i = 1; i < temp.length; i++) {
			temp[i] = false;
			
			System.out.println(i);

			for (int j = 1; j < a.length; j++) {
				if (i == a[j]) {
					temp[i] = true;
				}

			}

			System.out.println(temp[i]);
		}

//		for (int i = 0; i < a.length; i++) {
//			sum = sum + a[i];
//		}
		System.out.println(sum);

	}
}
