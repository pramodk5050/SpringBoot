package com.exponent.ExceptionHandling;

public class NoDataFoundByID extends Exception {

	public NoDataFoundByID(String message) {
		super(message);
	}
}
