package com.exponent.ExceptionHandling;

import java.util.Date;

public class ExceptionDetails {

	private String exceptionName;

	private String exceptionCause;

	private Date time;

	@Override
	public String toString() {
		return "ExceptionDetails [exceptionName=" + exceptionName + ", exceptionCause=" + exceptionCause + ", time="
				+ time + "]";
	}

	public String getExceptionName() {
		return exceptionName;
	}

	public void setExceptionName(String exceptionName) {
		this.exceptionName = exceptionName;
	}

	public String getExceptionCause() {
		return exceptionCause;
	}

	public void setExceptionCause(String exceptionCause) {
		this.exceptionCause = exceptionCause;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

}
