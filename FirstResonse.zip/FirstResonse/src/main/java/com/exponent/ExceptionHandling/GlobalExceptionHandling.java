package com.exponent.ExceptionHandling;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@ControllerAdvice
@RestControllerAdvice
public class GlobalExceptionHandling {

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<?> getNoDataFoundByIdException() {

		ExceptionDetails ex = new ExceptionDetails();
		ex.setExceptionCause("Invalid ID");
		ex.setExceptionName("noelement");
		ex.setTime(new Date());

		System.out.println(ex);

		return new ResponseEntity(ex, HttpStatus.BAD_REQUEST);

	}

}
