package com.exponent.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exponent.ExceptionHandling.NoDataFoundByID;
import com.exponent.Model.Student;
import com.exponent.repository.StudentRepo;

@RestController
@RequestMapping(value = "/exponent")
public class HomeController {

	@Autowired
	private StudentRepo sr;

	@RequestMapping(value = "/log")
	public ResponseEntity<?> getMsg() {
		return new ResponseEntity("hello Exponent Error page", HttpStatus.OK);
	}

	@RequestMapping(value = "/reg")
	public String registerData(@RequestBody Student st) {

		System.out.println(st);

		sr.save(st);

		return "Data Register Successfully!!";
	}

	// http:localhost:9100/exponent/getData/
	@RequestMapping(value = "/getData/{id}")
	public ResponseEntity<?> getDataFromID(@PathVariable("id") int sid) throws NoDataFoundByID {
		try {
			Student student = sr.findById(sid).get();

			System.out.println(student);

			return new ResponseEntity(student, HttpStatus.OK);
		} catch (Exception e) {

			throw new NoDataFoundByID("Invalid ID check it!!!!");
		}
	}

}
